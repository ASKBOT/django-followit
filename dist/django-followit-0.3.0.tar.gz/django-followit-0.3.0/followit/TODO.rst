* create tests & test runner script
* create doc pages
* publish on pypi
