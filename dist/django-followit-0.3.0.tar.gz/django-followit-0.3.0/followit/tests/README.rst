================
How to run tests
================

This is a test app for the ``followit``.

To run tests, jump into directory containing this file and launch the tests:
(make sure django is installed in site-packages)

python runtests.py  
